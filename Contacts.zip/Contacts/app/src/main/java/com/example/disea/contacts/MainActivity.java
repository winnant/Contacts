package com.example.disea.contacts;


import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.system.ErrnoException;
import android.system.Os;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FilenameFilter;
import java.io.InterruptedIOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static android.system.OsConstants.O_CREAT;
import static android.system.OsConstants.O_RDWR;


public class MainActivity extends AppCompatActivity implements ContactDialog.ContactDialogListener {
    public static RecyclerView.Adapter cAdapter;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;

    private TextView nameEntry;
    private TextView numberEntry;
    private List<Contacts> input = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        recyclerView.setHasFixedSize(true);


        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);


        nameEntry = (TextView) findViewById(R.id.name);
        numberEntry = (TextView) findViewById(R.id.number);
        loadContacts();
        Collections.sort(input);

        cAdapter = new ContactAdapter(input, this);
        recyclerView.setAdapter(cAdapter);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });
    }


    public void openDialog() {
        ContactDialog contactDialog = new ContactDialog();
        contactDialog.show(getSupportFragmentManager(), "example dialog");
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        switch (id) {
            case R.id.action_export:
                exportContacts();
                Toast.makeText(getApplicationContext(), "Contacts exported to new file.", Toast.LENGTH_LONG).show();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public void createContactFile(String name, String number) {
        Contacts contacts = new Contacts(name, number);

        if (!input.contains(contacts)) {
            input.add(contacts);
            Collections.sort(input);
            cAdapter.notifyDataSetChanged();
            createFile(contacts);
        } else {
            Toast.makeText(getApplicationContext(), "Duplicate Entry Encountered.", Toast.LENGTH_LONG).show();
        }


    }

    public void createFile(Contacts contacts) {
        String info = contacts.toString();
        byte buf[] = info.getBytes();
        String filename = contacts.getName();
        String pathname = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/" + filename + ".txt";
        try {
            File file = new File(pathname);
            FileDescriptor fd = Os.open(file.getAbsolutePath(), O_RDWR | O_CREAT, 00777);
            Os.write(fd, buf, 0, info.length());
            Os.close(fd);

            Toast.makeText(getApplicationContext(), "File successfully saved.", Toast.LENGTH_LONG).show();

        } catch (ErrnoException e) {
            Toast.makeText(getApplicationContext(), "Failed to open file.", Toast.LENGTH_LONG).show();
        } catch (InterruptedIOException e) {
            Toast.makeText(getApplicationContext(), "Failed to write to file.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    public void loadContacts() {
        String directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/";
        final File contactFiles = new File(directory);
        FilenameFilter textFilter = new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                String lowercasename = name.toLowerCase();
                if (lowercasename.startsWith("_masterlist")) return false;
                return true;
            }
        };

        if (contactFiles.isDirectory() && contactFiles.list().length > 0) {
            File[] cFiles = contactFiles.listFiles(textFilter);

            for (int i = 0; i < cFiles.length; i++) {
                try {
                    ByteBuffer holding = ByteBuffer.allocate((int) cFiles[i].length());
                    FileDescriptor filedes = Os.open(cFiles[i].getAbsolutePath(), O_RDWR, 00777);
                    Os.read(filedes, holding);
                    Os.close(filedes);

                    String info = new String(holding.array());
                    String[] contactFields = info.split("\n", 2);
                    String name = contactFields[0];
                    String number = contactFields[1];
                    Contacts contact = new Contacts(name, number);
                    input.add(contact);

                } catch (ErrnoException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Failed to open file.", Toast.LENGTH_LONG).show();
                } catch (InterruptedIOException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Failed to read file.", Toast.LENGTH_LONG).show();

                }
            }
        }
    }


    public void exportContacts() {
        String directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/";
        final File contactFiles = new File(directory);
        FilenameFilter textFilter = new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                String lowercasename = name.toLowerCase();
                if (lowercasename.startsWith("_masterlist")) return false;
                return true;
            }
        };

        String masterstring = "";
        if (contactFiles.isDirectory() && contactFiles.list().length > 0) {
            File[] cFiles = contactFiles.listFiles(textFilter);
            Arrays.sort(cFiles);
            for (int i = 0; i < cFiles.length; i++) {
                byte[] holding = new byte[(int) cFiles[i].length()];
                try {

                    FileDescriptor filedes = Os.open(cFiles[i].getAbsolutePath(), O_RDWR, 00777);
                    Os.read(filedes, holding, 0, (int) cFiles[i].length());
                    Os.close(filedes);


                } catch (ErrnoException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Failed to open file.", Toast.LENGTH_LONG).show();
                } catch (InterruptedIOException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Failed to read file.", Toast.LENGTH_LONG).show();

                }
                String item = new String(holding);
                masterstring = masterstring + "\n" + item;

            }
            Log.d("MASTERSTRING: ", masterstring);
            byte[] export = masterstring.getBytes();
            String pathname = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/" + "_masterlist.txt";
            File masterfile = new File(pathname);
            try {
                FileDescriptor masterfd = Os.open(masterfile.getAbsolutePath(), O_RDWR | O_CREAT, 00777);
                Os.ftruncate(masterfd,export.length);
                Os.write(masterfd, export, 0, export.length);
                Os.close(masterfd);
            } catch (ErrnoException e) {
                e.printStackTrace();
            } catch (InterruptedIOException e) {
                e.printStackTrace();
            }

        }


    }

    @Override
    public void onResume() {
        super.onResume();
        input.clear();
        loadContacts();
        Collections.sort(input);
        cAdapter.notifyDataSetChanged();
    }


}
