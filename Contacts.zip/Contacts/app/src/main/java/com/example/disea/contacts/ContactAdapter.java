package com.example.disea.contacts;

import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.support.v7.widget.RecyclerView;
import android.system.ErrnoException;
import android.system.Os;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.List;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ViewHolder> {
    private List<Contacts> ContactList;
    private Context mContext;



    // Provide a suitable constructor (depends on the kind of dataset)
    public ContactAdapter(List<Contacts> list, Context context) {
        ContactList = list;
        mContext = context;
    }

    public void add(int position, Contacts item) {
        ContactList.add(position, item);

    }

    public void remove(int position) {
        ContactList.remove(position);
        notifyItemRemoved(position);
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return ContactList.size();
    }

    @Override
    public ContactAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                        int viewType) {
        // create a new view
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v =
                inflater.inflate(R.layout.row_layout, parent, false);
        // set the view's size, margins, paddings and layout parameters
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override

    public void onBindViewHolder(final ViewHolder holder, final int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        final Contacts name = ContactList.get(position);

        holder.txtHeader.setText(name.getName());
        holder.txtFooter.setText(name.getNumber());
        holder.txtDot.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {


                final PopupMenu popupMenu = new PopupMenu(mContext, holder.txtHeader);
                popupMenu.inflate(R.menu.popup_menu);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        String filename = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/" + name.getName() + ".txt";
                        switch (item.getItemId()) {
                            case R.id.edit_item:
                                Intent intent = new Intent(mContext, EditContactActivity.class);
                                intent.putExtra("Original filename", filename);
                                intent.putExtra("original name",name.getName());
                                intent.putExtra("original number",name.getNumber());
                                mContext.startActivity(intent);


                                break;
                            case R.id.delete_item:
                                try {
                                    Os.remove(filename);
                                    remove(position);
                                } catch (ErrnoException e) {
                                    Toast.makeText(mContext, "No file found.", Toast.LENGTH_LONG).show();
                                    e.printStackTrace();
                                }
                                Toast.makeText(mContext, "File Deleted", Toast.LENGTH_LONG).show();
                                break;
                            default:
                                break;
                        }
                        return false;
                    }
                });
                popupMenu.show();
            }
        });

        holder.txtFooter.setText(name.getNumber());
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public TextView txtHeader;
        public TextView txtFooter;
        public TextView txtDot;
        public View layout;

        public ViewHolder(View v) {
            super(v);
            layout = v;
            txtHeader = (TextView) v.findViewById(R.id.name);
            txtFooter = (TextView) v.findViewById(R.id.number);
            txtDot = (TextView) v.findViewById(R.id.dots);


        }

    }


}