package com.example.disea.contacts;

public class Contacts implements Comparable<Contacts> {
    private String name;
    private String number;

    public Contacts(String name, String number) {
        super();
        this.name = name;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String toString() {
        return name + "\n" + number;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public int compareTo(Contacts contact) {
        if (this.name.compareTo(contact.name) == 0) return this.number.compareTo(contact.number);
        else return this.name.compareTo(contact.name);
    }

    @Override
    public boolean equals(Object contact) {
        if (!(contact instanceof Contacts)) return false;
        if (this == contact) return true;
        if (contact == null) return false;
        if (getClass() != contact.getClass()) return false;
        Contacts other = (Contacts) contact;
        return other.toString().equals(this.toString());

    }


}

