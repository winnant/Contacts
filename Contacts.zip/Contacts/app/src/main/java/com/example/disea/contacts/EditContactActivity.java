package com.example.disea.contacts;


import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.system.ErrnoException;
import android.system.Os;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileDescriptor;
import java.io.InterruptedIOException;

import static android.system.OsConstants.O_RDWR;

public class EditContactActivity extends AppCompatActivity {
    private EditText nameEntry;
    private EditText numberEntry;
    private String oldFilename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editactivity_layout);
        Intent intent = getIntent();
        oldFilename = intent.getExtras().getString("Original filename");
        nameEntry = (EditText) findViewById(R.id.e_name);
        numberEntry = (EditText) findViewById(R.id.e_number);
        nameEntry.setText(intent.getExtras().getString("original name"));
        numberEntry.setText(intent.getExtras().getString("original number"));


        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editFile(oldFilename);
                finish();
            }
        });


    }

    public void editFile(String oldfname) {
        Contacts newContact = new Contacts(nameEntry.getText().toString(), numberEntry.getText().toString());
        String oldFilename = oldfname;
        Log.d("TEST: ", oldFilename);
        String newFileinfo = newContact.toString();
        String newFilename = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/" + newContact.getName() + ".txt";
        byte buf[] = newFileinfo.getBytes();

        try {
            FileDescriptor fd = Os.open(oldFilename, O_RDWR, 00777);
            Os.ftruncate(fd, buf.length);
            Os.write(fd, buf, 0, newFileinfo.length());
            Os.close(fd);
            Os.rename(oldFilename, newFilename);

            Toast.makeText(getApplicationContext(), "File saved", Toast.LENGTH_LONG).show();


        } catch (ErrnoException e) {
            e.printStackTrace();
        } catch (InterruptedIOException e) {
            e.printStackTrace();
        }

    }

}
